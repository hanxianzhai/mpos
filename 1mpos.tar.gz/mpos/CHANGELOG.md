0.0.1 (Mar 7th 2013)
--------------------

* WiP Upload of all files currently available
* Added upstream script collections
* Added SQL structure 
