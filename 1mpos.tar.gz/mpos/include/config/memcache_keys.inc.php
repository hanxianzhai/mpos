<?php

// Make sure we are called from index.php
if (!defined('SECURITY')) die('Hacking attempt');

define('STATISTICS_ALL_USER_SHARES', 'STATISTICS_ALL_USER_SHARES');
define('STATISTICS_ALL_USER_HASHRATES', 'STATISTICS_ALL_USER_HASHRATES');
define('STATISTICS_ROUND_SHARES', 'STATISTICS_ROUND_SHARES');
?>
