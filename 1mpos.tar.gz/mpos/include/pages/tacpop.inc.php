<?php

// Make sure we are called from index.php
if (!defined('SECURITY')) die('Hacking attempt');
$master_template = 'tac/default.tpl';
?>
