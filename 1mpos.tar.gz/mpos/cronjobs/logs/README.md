Logging directory for cronjobs.
