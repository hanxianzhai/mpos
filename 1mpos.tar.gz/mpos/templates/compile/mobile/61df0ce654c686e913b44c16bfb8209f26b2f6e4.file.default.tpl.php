<?php /* Smarty version Smarty-3.1.16, created on 2014-01-26 00:47:03
         compiled from "./templates/mobile/error//default.tpl" */ ?>
<?php /*%%SmartyHeaderCode:180055189752e3ea87eee713-48990722%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '61df0ce654c686e913b44c16bfb8209f26b2f6e4' => 
    array (
      0 => './templates/mobile/error//default.tpl',
      1 => 1390224332,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '180055189752e3ea87eee713-48990722',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.16',
  'unifunc' => 'content_52e3ea880060c6_81046143',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_52e3ea880060c6_81046143')) {function content_52e3ea880060c6_81046143($_smarty_tpl) {?>    <p>The page you requested was not found.</p>
<?php }} ?>
