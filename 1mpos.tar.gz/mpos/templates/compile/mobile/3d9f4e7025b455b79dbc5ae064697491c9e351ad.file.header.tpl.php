<?php /* Smarty version Smarty-3.1.16, created on 2014-01-20 23:39:27
         compiled from "./templates/mobile/global/header.tpl" */ ?>
<?php /*%%SmartyHeaderCode:29053123852dd432fe0e4f1-78123545%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '3d9f4e7025b455b79dbc5ae064697491c9e351ad' => 
    array (
      0 => './templates/mobile/global/header.tpl',
      1 => 1390224332,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '29053123852dd432fe0e4f1-78123545',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'GLOBAL' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.16',
  'unifunc' => 'content_52dd432fe23767_98137618',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_52dd432fe23767_98137618')) {function content_52dd432fe23767_98137618($_smarty_tpl) {?>          <h2><?php echo (($tmp = @$_smarty_tpl->tpl_vars['GLOBAL']->value['website']['name'])===null||$tmp==='' ? "The Pool" : $tmp);?>
</h2>
<?php }} ?>
