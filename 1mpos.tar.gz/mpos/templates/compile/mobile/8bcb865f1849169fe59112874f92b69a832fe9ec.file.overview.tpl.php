<?php /* Smarty version Smarty-3.1.16, created on 2014-02-01 20:01:10
         compiled from "./templates/mobile/dashboard/overview.tpl" */ ?>
<?php /*%%SmartyHeaderCode:66543482952ece206ee1bb5-63563202%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '8bcb865f1849169fe59112874f92b69a832fe9ec' => 
    array (
      0 => './templates/mobile/dashboard/overview.tpl',
      1 => 1390224332,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '66543482952ece206ee1bb5-63563202',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.16',
  'unifunc' => 'content_52ece206eea999_05220741',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_52ece206eea999_05220741')) {function content_52ece206eea999_05220741($_smarty_tpl) {?>  <div class="module_content">
    <div style="display: inline-block;">
      <div id="hashrate" style="width:180px; height:120px;"></div>
      <div id="sharerate" style="width:180px; height:120px;"></div>
    </div>
    <div style="display: inline-block;">
      <div id="poolhashrate" style="width:100px; height:80px;"></div>
      <div id="nethashrate" style="width:100px; height:80px;"></div>
      <div id="querytime" style="width:100px; height:80px;"></div>
    </div>
  </div>
<?php }} ?>
