<?php /* Smarty version Smarty-3.1.16, created on 2014-02-07 15:19:53
         compiled from "templates/mail/subject.tpl" */ ?>
<?php /*%%SmartyHeaderCode:79360073052f489199f7284-26551021%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'd0c21d0ecaf6525990d050cd075cabc3ed618aca' => 
    array (
      0 => 'templates/mail/subject.tpl',
      1 => 1390224332,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '79360073052f489199f7284-26551021',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'WEBSITENAME' => 0,
    'SUBJECT' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.16',
  'unifunc' => 'content_52f48919ac4005_63872824',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_52f48919ac4005_63872824')) {function content_52f48919ac4005_63872824($_smarty_tpl) {?>[ <?php echo $_smarty_tpl->tpl_vars['WEBSITENAME']->value;?>
 ] <?php echo $_smarty_tpl->tpl_vars['SUBJECT']->value;?>

<?php }} ?>
