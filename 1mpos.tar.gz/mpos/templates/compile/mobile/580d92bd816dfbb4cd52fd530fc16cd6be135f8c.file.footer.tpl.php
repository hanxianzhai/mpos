<?php /* Smarty version Smarty-3.1.16, created on 2014-01-20 23:39:27
         compiled from "./templates/mobile/global/footer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:135835454652dd432feb9030-72081792%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '580d92bd816dfbb4cd52fd530fc16cd6be135f8c' => 
    array (
      0 => './templates/mobile/global/footer.tpl',
      1 => 1390224332,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '135835454652dd432feb9030-72081792',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.16',
  'unifunc' => 'content_52dd432febdc16_37030415',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_52dd432febdc16_37030415')) {function content_52dd432febdc16_37030415($_smarty_tpl) {?>          <h1>Powered by <a target="_blank" href="https://github.com/TheSerapher/php-mpos" data-ajax="false">MPOS</a></h1>
<?php }} ?>
