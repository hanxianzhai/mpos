<?php /* Smarty version Smarty-3.1.16, created on 2014-01-21 00:07:43
         compiled from "./templates/mpos/about/donors/disabled.tpl" */ ?>
<?php /*%%SmartyHeaderCode:79052732952dd49cf89eef1-63241891%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '06019dc179f5d11c33f34e862b29a05bc2124e6f' => 
    array (
      0 => './templates/mpos/about/donors/disabled.tpl',
      1 => 1390224332,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '79052732952dd49cf89eef1-63241891',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.16',
  'unifunc' => 'content_52dd49cf8a3f01_12530448',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_52dd49cf8a3f01_12530448')) {function content_52dd49cf8a3f01_12530448($_smarty_tpl) {?><?php }} ?>
