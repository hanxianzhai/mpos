<?php /* Smarty version Smarty-3.1.16, created on 2014-02-13 03:03:50
         compiled from "hybrid:global/footer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:123201833752de3220ec76f0-98181614%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '941a8d4319031ad9f0a7f075a957012aee3fbdbd' => 
    array (
      0 => 'hybrid:global/footer.tpl',
      1 => 1392231824,
      2 => 'hybrid',
    ),
  ),
  'nocache_hash' => '123201833752de3220ec76f0-98181614',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.16',
  'unifunc' => 'content_52de3221026511_82934455',
  'variables' => 
  array (
    'DEBUG' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_52de3221026511_82934455')) {function content_52de3221026511_82934455($_smarty_tpl) {?>    <p><strong>FRSC</strong> QQ group: 94479366 / 110979767  Contact us: admin@federalreservecoin.org</p>
    <p>Please <strong>Donate</strong> to <a href="http://federalreservecoin.org " target="_blank">federalreservecoin.org</a> FRSC: Ldo4WPCkNTnGyJVgBsHd9CeyDB4majitWg</p>
    <p>Copyright © 2013 Sebastian Grewe, Theme by MediaLoot</p>
    <?php if ($_smarty_tpl->tpl_vars['DEBUG']->value>0) {?>
    <div id="debug">
      <?php echo $_smarty_tpl->getSubTemplate ("system/debugger.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

    </div>
    <?php }?><?php }} ?>
