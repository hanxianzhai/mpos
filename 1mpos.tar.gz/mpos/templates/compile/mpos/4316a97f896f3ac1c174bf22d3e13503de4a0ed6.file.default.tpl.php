<?php /* Smarty version Smarty-3.1.16, created on 2014-01-21 09:29:34
         compiled from "./templates/mpos/about//default.tpl" */ ?>
<?php /*%%SmartyHeaderCode:65493185052ddcd7e51a618-18861413%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '4316a97f896f3ac1c174bf22d3e13503de4a0ed6' => 
    array (
      0 => './templates/mpos/about//default.tpl',
      1 => 1390224332,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '65493185052ddcd7e51a618-18861413',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.16',
  'unifunc' => 'content_52ddcd7e51f784_34008574',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_52ddcd7e51f784_34008574')) {function content_52ddcd7e51f784_34008574($_smarty_tpl) {?><?php }} ?>
