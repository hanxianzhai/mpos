<?php /* Smarty version Smarty-3.1.16, created on 2014-01-26 11:34:57
         compiled from "./templates/mpos/account/confirm/default.tpl" */ ?>
<?php /*%%SmartyHeaderCode:169949541152e482615c2315-26366664%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c18fd16cde3df61a9e078b078fcb577cbc162481' => 
    array (
      0 => './templates/mpos/account/confirm/default.tpl',
      1 => 1390224332,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '169949541152e482615c2315-26366664',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.16',
  'unifunc' => 'content_52e4826162f014_42516483',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_52e4826162f014_42516483')) {function content_52e4826162f014_42516483($_smarty_tpl) {?>
<?php }} ?>
