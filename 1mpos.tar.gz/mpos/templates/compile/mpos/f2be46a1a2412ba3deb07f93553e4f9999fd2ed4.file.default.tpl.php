<?php /* Smarty version Smarty-3.1.16, created on 2014-01-21 08:21:24
         compiled from "./templates/mpos/error//default.tpl" */ ?>
<?php /*%%SmartyHeaderCode:14778472452ddbd84ef7e51-36378402%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f2be46a1a2412ba3deb07f93553e4f9999fd2ed4' => 
    array (
      0 => './templates/mpos/error//default.tpl',
      1 => 1390224332,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '14778472452ddbd84ef7e51-36378402',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'GLOBAL' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.16',
  'unifunc' => 'content_52ddbd85027b32_75979937',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_52ddbd85027b32_75979937')) {function content_52ddbd85027b32_75979937($_smarty_tpl) {?><article class="module width_full">
  <header><h3><?php echo $_smarty_tpl->tpl_vars['GLOBAL']->value['website']['name'];?>
</h3></header>
  <div class="module_content">
    <p>The page you requested was not found.</p>
  </div>
</article>
<?php }} ?>
