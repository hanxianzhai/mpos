<?php /* Smarty version Smarty-3.1.16, created on 2014-01-21 03:21:02
         compiled from "/var/www/templates/mail/global/footer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:144556792552dd771e41d956-44390976%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '0b76f80a2103c9c7323db39b290e1fb529040650' => 
    array (
      0 => '/var/www/templates/mail/global/footer.tpl',
      1 => 1390224332,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '144556792552dd771e41d956-44390976',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.16',
  'unifunc' => 'content_52dd771e4314e0_53752177',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_52dd771e4314e0_53752177')) {function content_52dd771e4314e0_53752177($_smarty_tpl) {?></body>
</html>
<?php }} ?>
