<?php /* Smarty version Smarty-3.1.16, created on 2014-01-20 23:26:58
         compiled from "./templates/mpos/dashboard/round_data.tpl" */ ?>
<?php /*%%SmartyHeaderCode:138424245452dd4042a9a333-89722072%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '179b8f365ea15039ce363df30bb19fc2a75b4676' => 
    array (
      0 => './templates/mpos/dashboard/round_data.tpl',
      1 => 1390224332,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '138424245452dd4042a9a333-89722072',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.16',
  'unifunc' => 'content_52dd4042a9f2b5_45575501',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_52dd4042a9f2b5_45575501')) {function content_52dd4042a9f2b5_45575501($_smarty_tpl) {?><article class="module width_quarter">
  <header><h3>Round Information</h3></header>
  <div class="module_content">
    <div id="shareinfograph" style="width: 100%; height: 100%;"></div>
  </div>
  <footer>
  </footer>
</article>
<?php }} ?>
