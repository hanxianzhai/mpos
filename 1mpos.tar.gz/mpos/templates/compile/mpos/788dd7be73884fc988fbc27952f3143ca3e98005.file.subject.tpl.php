<?php /* Smarty version Smarty-3.1.16, created on 2014-01-21 00:57:01
         compiled from "../templates/mail/subject.tpl" */ ?>
<?php /*%%SmartyHeaderCode:8313107652dd555d9edd65-01615111%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '788dd7be73884fc988fbc27952f3143ca3e98005' => 
    array (
      0 => '../templates/mail/subject.tpl',
      1 => 1390224332,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '8313107652dd555d9edd65-01615111',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'WEBSITENAME' => 0,
    'SUBJECT' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.16',
  'unifunc' => 'content_52dd555da710b0_76354257',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_52dd555da710b0_76354257')) {function content_52dd555da710b0_76354257($_smarty_tpl) {?>[ <?php echo $_smarty_tpl->tpl_vars['WEBSITENAME']->value;?>
 ] <?php echo $_smarty_tpl->tpl_vars['SUBJECT']->value;?>

<?php }} ?>
