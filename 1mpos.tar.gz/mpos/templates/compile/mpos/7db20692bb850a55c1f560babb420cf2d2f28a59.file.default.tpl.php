<?php /* Smarty version Smarty-3.1.16, created on 2014-01-22 23:25:00
         compiled from "./templates/mpos/account//default.tpl" */ ?>
<?php /*%%SmartyHeaderCode:12494578752dfe2ccaf5970-79505108%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '7db20692bb850a55c1f560babb420cf2d2f28a59' => 
    array (
      0 => './templates/mpos/account//default.tpl',
      1 => 1390224332,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '12494578752dfe2ccaf5970-79505108',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.16',
  'unifunc' => 'content_52dfe2ccb48d35_30873265',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_52dfe2ccb48d35_30873265')) {function content_52dfe2ccb48d35_30873265($_smarty_tpl) {?>No action specified
<?php }} ?>
