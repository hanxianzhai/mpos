<?php /* Smarty version Smarty-3.1.16, created on 2014-01-21 14:22:28
         compiled from "./templates/mpos/admin/reports/default.tpl" */ ?>
<?php /*%%SmartyHeaderCode:29535330752de12241ee587-88888676%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '8ce65f2b980fc18e2dc8ebf84a83dfe8fb85dd0a' => 
    array (
      0 => './templates/mpos/admin/reports/default.tpl',
      1 => 1390224332,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '29535330752de12241ee587-88888676',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.16',
  'unifunc' => 'content_52de122424f908_42637777',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_52de122424f908_42637777')) {function content_52de122424f908_42637777($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("admin/reports/earnings_control.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

<?php echo $_smarty_tpl->getSubTemplate ("admin/reports/earnings_report.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

<?php }} ?>
