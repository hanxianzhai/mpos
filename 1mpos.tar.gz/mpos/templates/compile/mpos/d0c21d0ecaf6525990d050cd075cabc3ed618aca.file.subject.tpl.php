<?php /* Smarty version Smarty-3.1.16, created on 2014-01-21 00:41:14
         compiled from "templates/mail/subject.tpl" */ ?>
<?php /*%%SmartyHeaderCode:132844978352dd51aae7fc07-35588880%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'd0c21d0ecaf6525990d050cd075cabc3ed618aca' => 
    array (
      0 => 'templates/mail/subject.tpl',
      1 => 1390224332,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '132844978352dd51aae7fc07-35588880',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'WEBSITENAME' => 0,
    'SUBJECT' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.16',
  'unifunc' => 'content_52dd51ab061e00_70702651',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_52dd51ab061e00_70702651')) {function content_52dd51ab061e00_70702651($_smarty_tpl) {?>[ <?php echo $_smarty_tpl->tpl_vars['WEBSITENAME']->value;?>
 ] <?php echo $_smarty_tpl->tpl_vars['SUBJECT']->value;?>

<?php }} ?>
