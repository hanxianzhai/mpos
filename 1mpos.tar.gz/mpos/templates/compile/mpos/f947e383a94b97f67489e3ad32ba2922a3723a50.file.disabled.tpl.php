<?php /* Smarty version Smarty-3.1.16, created on 2014-01-21 10:26:50
         compiled from "./templates/mpos/about/pool/disabled.tpl" */ ?>
<?php /*%%SmartyHeaderCode:4006232652dddaea366b60-44834090%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f947e383a94b97f67489e3ad32ba2922a3723a50' => 
    array (
      0 => './templates/mpos/about/pool/disabled.tpl',
      1 => 1390224332,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '4006232652dddaea366b60-44834090',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.16',
  'unifunc' => 'content_52dddaea36b250_01408820',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_52dddaea36b250_01408820')) {function content_52dddaea36b250_01408820($_smarty_tpl) {?><?php }} ?>
