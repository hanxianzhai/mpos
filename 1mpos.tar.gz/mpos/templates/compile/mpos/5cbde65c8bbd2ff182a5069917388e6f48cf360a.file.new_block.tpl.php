<?php /* Smarty version Smarty-3.1.16, created on 2014-01-21 00:57:01
         compiled from "../templates/mail/notifications/new_block.tpl" */ ?>
<?php /*%%SmartyHeaderCode:126236646952dd555da77350-69488321%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '5cbde65c8bbd2ff182a5069917388e6f48cf360a' => 
    array (
      0 => '../templates/mail/notifications/new_block.tpl',
      1 => 1390224332,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '126236646952dd555da77350-69488321',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.16',
  'unifunc' => 'content_52dd555da7d510_61198334',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_52dd555da7d510_61198334')) {function content_52dd555da7d510_61198334($_smarty_tpl) {?><html>
<body>
<p>A new block has been discovered!</p>
<br/>
<br/>
</body>
</html>
<?php }} ?>
