ALTER TABLE  `settings` CHANGE  `value`  `value` TEXT CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL ;
