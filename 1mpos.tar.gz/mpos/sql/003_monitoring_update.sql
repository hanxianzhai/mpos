ALTER TABLE  `monitoring` CHANGE  `value`  `value` VARCHAR( 255 ) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL ;
