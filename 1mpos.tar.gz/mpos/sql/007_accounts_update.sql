ALTER TABLE  `accounts` ADD  `failed_pins` INT NOT NULL AFTER  `failed_logins` ;
