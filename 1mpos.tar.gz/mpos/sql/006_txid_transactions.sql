ALTER TABLE  `transactions` ADD  `txid` VARCHAR( 256 ) NULL DEFAULT NULL AFTER  `timestamp` ;
