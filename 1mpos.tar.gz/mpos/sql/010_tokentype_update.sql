INSERT INTO `token_types` (`name`, `expiration`) VALUES ('account_unlock', 0);
