ALTER TABLE  `shares_archive` ADD INDEX (  `username` ) ;
ALTER TABLE  `shares_archive` ADD INDEX (  `share_id` ) ;
ALTER TABLE  `shares_archive` ADD INDEX (  `our_result` ) ;
ALTER TABLE  `shares_archive` ADD INDEX (  `time` ) ;
